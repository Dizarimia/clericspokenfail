import os

os.environ["DATABASE_URL"] = "postgres://yrgaccce:YQMxbONQLk5LSJ4szzCEg64itSzBTqP2@balarama.db.elephantsql.com/yrgaccce"
os.environ["SECRET_KEY"] = "8en6s*56pf+^6&ds1$1pdg0!e-4&npzrc$qoyx0^a0y)v6rga@"
os.environ["CLOUDINARY_URL"] = "cloudinary://738314813239996:vUccGQmQsxSBfBTBc_hDDF0kDVc@dhdna3rfz"